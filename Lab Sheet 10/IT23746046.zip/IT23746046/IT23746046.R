setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT23746046")

#Exercise
# i. State the null and alternative hypotheses for the test.
observed <- c(120,95,85,100)
prob <- c(0.25,0.25,0.25,0.25)

# ii. Perform a suitable chi-squared test to test the null hypothesis.
chisq.test(x=observed, p=prob)

# iii. Give your conclusions based on the results.
    #Since the p-value (0.08966) is greater than the significance level of 0.05, we fail to reject the null hypothesis.
    #Therefore, there is no significant association between snack and type at the 5% level of significance.


